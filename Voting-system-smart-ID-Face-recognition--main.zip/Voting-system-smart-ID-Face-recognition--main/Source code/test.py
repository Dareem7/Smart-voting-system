
print(round(94.0))